

$(document).ready(function() {


    /**
     * Emplacement de méthodes onSuccess, onError et displayResults
     */






    if(window.openDatabase){
        /**
         * Creation de la base de donnée
         */


    };


    /**
     *  Requête INSERT
     */
    $("#persistWebSql").click(function () {


    })


    /**
     * Requête SELECT
     */
    $("#affichageWebSQL").click(function(){


    })

    /**
     * Requête DELETE
     */
    $("#delEntrySQL").click(function(){


    })

    /**
     * Requête DELETE ALL
     */
    $("#delBDDSQL").click(function(){


    })
})