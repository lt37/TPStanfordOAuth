
// fichier javascript pour la bdd offline webStorage par clé valeur

function Entry() {
    this.nom = "";
    this.prenom = "";
    this.civilite = "";
    this.rueVoie = "";
    this.codePostal = "";
    this.ville = "";
    this.pays = "";
    this.numTel = "";
}

$(document).ready(function() {

    $("#persistWebStorage").click(function () {

        // ya plus qu'a

    });

    $("#affichageWebStorage").click(function () {

        // ya plus qu'a

    });

    $("#delEntryWS").click(function () {

        // ya plus qu'a

    });

    $("#delBDDWS").click(function () {

        // ya plus qu'a

    });
});