function Entry() {
    this.nom = "";
    this.prenom = "";
    this.mail = "";
    this.civilite = "";
    this.rueVoie = "";
    this.codePostal = "";
    this.ville = "";
    this.pays = "";
    this.numTel = "";
}

$(document).ready(function() {

    $("#persistIndexDB").click(function () {

        // ya plus qu'a

    });

    $("#affichageIndexedDB").click(function () {

        // ya plus qu'a

    });

    $("#delEntryIDB").click(function () {

        // ya plus qu'a

    });

    $("#delBDDIDB").click(function () {

        // ya plus qu'a

    });
});
